
public class Programa {

	public static void main(String[] args) {
	
	int arregloUno [][] = {{1,2,3}, {4,5,6}, {7,8,9}};
	int arregloDos [][] = {{4,5,6}, {10,11,12}, {7,8,9}};
	Matriz uno = new Matriz();
	
	/*Escribe un metodo que multiplique dos matrices y muestre el resultado. Las matrices pueden ser de
	cualquier tamano, pero deben ser compatibles para multiplicarse.*/
	uno.multiplicarMatrices(arregloUno, arregloDos);
	System.out.println();

	/*Transponer una matriz, escriba un metodo que tome una matriz como entrada y devuelva la
	transpuesta de dicha matriz.*/
	uno.transponerMatriz(arregloUno);
	System.out.println();
		
	/*Suma diagonal: escribe un metodo que tome una matriz cuadrada como entrada y devuelva la suma
	de los elementos de la diagonal principal.*/
	System.out.println(uno.sumaDiagonalMatriz(arregloUno));
	System.out.println(uno.sumaDiagonalMatriz(arregloDos));
	System.out.println();
		
	/*Encuentra el maximo: escribe un mÃ©todo que reciba una matriz de entrada y que devuelva el valor
	mas grande de la matriz*/
	System.out.println(uno.maximoMatriz(arregloDos));
	System.out.println(uno.maximoMatriz(arregloUno));
	System.out.println();
		
	/*Suma dos matrices: escribe un metodo que reciba dos matrices de entrada y devuelva la matriz
	sumada.*/
	uno.sumaDosMatrices(arregloUno, arregloDos);
	System.out.println();
		
	/*Multiplicar una matriz por un escalar: Escribe un metodo que reciba cualquier matriz y un escalar
	como entradas y devuelve el producto de la matriz por el escalar.*/
	uno.multiplicarEscalarMatriz(arregloUno, 3);
	}
}
