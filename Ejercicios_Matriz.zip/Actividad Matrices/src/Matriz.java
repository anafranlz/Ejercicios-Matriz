
public class Matriz {
	
	int i, j, k, max, sumaDiagonal;
	/*Escribe un metodo que multiplique dos matrices y muestre el resultado. Las matrices
	pueden ser de cualquier tamano, pero deben ser compatibles para multiplicarse.*/
	//DONEEEE
	public void multiplicarMatrices(int arrayOne [][], int arrayTwo [][])
	{
		int[][] matrizMultiplicada = new int[arrayOne.length][arrayTwo[0].length];
		for(i = 0; i<arrayOne.length; i++)
		{
			for(j = 0; j<arrayTwo[0].length; j++)
			{
				for(k = 0; k<arrayTwo.length; k++)
				{
					matrizMultiplicada[i][j]+= (arrayOne[i][k] * arrayTwo[k][j]);
				}
			}
		}
		for(i = 0; i<matrizMultiplicada.length; i++)
		{
			for(j = 0; j<matrizMultiplicada[i].length; j++)
			{
				System.out.print(matrizMultiplicada[i][j] + " ");
			}
			System.out.println();
		}
		return;
	}

	/*Transponer una matriz, escriba un metodo que tome una matriz como entrada y
	devuelva la transpuesta de dicha matriz.*/
	//DONEEEE
	public void transponerMatriz(int array [][])
	{
		int[][] matrizTranspuesta = new int[array.length][array[0].length];
		for(i = 0; i<array.length; i++)
		{
			for(j = 0; j<array[i].length; j++)
			{
				matrizTranspuesta[i][j] = array[j][i];
			}
		}
		for(i = 0; i<array.length; i++)
		{
			for(j = 0; j<array[i].length; j++)
			{
				System.out.print(matrizTranspuesta[i][j] + " ");
			}
			System.out.println();
		}
	}
		
	/*Suma diagonal: escribe un metodo que tome una matriz cuadrada como entrada y
	devuelva la suma de los elementos de la diagonal principal.*/
	//DONEEEEE
	public int sumaDiagonalMatriz(int array [][])
	{
		sumaDiagonal = 0;
		for(i = 0; i<array.length; i++)
		{
			for(j = 0; j<array[i].length; j++)
			{
				if(i == j)
				{
					sumaDiagonal+=array[i][j];
				}
			}
		}
		return sumaDiagonal;
	}
		
	/*Encuentra el maximo: escribe un metodo que reciba una matriz de entrada y que
	devuelva el valor mas grande de la matriz*/
	//DONEEEE !!!!!
	public int maximoMatriz(int array[][])
	{
		max = array[0][0];
		for(i = 0; i<array.length; i++)
		{
			for(j = 0; j<array[i].length; j++)
			{
				if(array[i][j] > max)
				{
					max = array[i][j];
				}
			}
		}
		return max;
	}
	
	/*Suma dos matrices: escribe un metodo que reciba dos matrices de entrada y devuelva
	la matriz sumada.*/
	//DONEEEEEE
	public void sumaDosMatrices(int arrayOne [][], int arrayTwo [][])
	{
		int[][] matrizSumada = new int[arrayOne.length][arrayTwo[0].length];
		for(i = 0; i<arrayOne.length; i++)
		{
			for(j = 0; j<arrayOne[i].length; j++)
			{
				matrizSumada[i][j] = arrayOne[i][j] + arrayTwo[i][j];
			}
		}
		for(i = 0; i<arrayOne.length; i++)
		{
			for(j = 0; j<arrayOne[i].length; j++)
			{
				System.out.print(matrizSumada[i][j] + " ");
			}
			System.out.println();
		}
		return;
	}	
	
	/*Multiplicar una matriz por un escalar: Escribe un metodo que reciba cualquier matriz
	y un escalar como entradas y devuelve el producto de la matriz por el escalar.*/
	public void multiplicarEscalarMatriz(int array [][], int escalar)
	{
		int[][] matrizEscalarMultiplicada = new int[array.length][array[0].length];
		for(i = 0; i<array.length; i++)
		{
			for(j = 0; j<array[i].length; j++)
			{
				matrizEscalarMultiplicada[i][j] = (array[i][j] * escalar);
			}
		}
		for(i = 0; i<array.length; i++)
		{
			for(j = 0; j<array[i].length; j++)
			{
				System.out.print(matrizEscalarMultiplicada[i][j] + " ");
			}
			System.out.println();
		}
		return;
	}
}
